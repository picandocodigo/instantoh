#Instant "Oh the Humanity!" button

Just a website I made for fun: http://instantohthehumanity.com

![Oh the Humanity](https://raw.github.com/picandocodigo/instantoh/gh-pages/images/firefox-os.jpg)

The audio is from Herbert Morrison's report of the [Hindenburg disaster](http://en.wikipedia.org/wiki/Hindenburg_disaster).
